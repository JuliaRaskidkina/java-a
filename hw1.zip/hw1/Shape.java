package ru.mipt.java.hw1;

/**
 * Created by User on 24.09.2017.
 */
public interface Shape {

    double area();
}
